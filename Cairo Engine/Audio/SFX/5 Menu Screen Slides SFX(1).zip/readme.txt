Need Custom music/sfx for your project?
you can contact me by e-mail: cleytonkauffman@gmail.com

If you have any doubt with game audio stuffs,
you can contact me as well (:

========[Facebook

https://www.facebook.com/ckcomposer/

========[Soundcloud

https://soundcloud.com/cleytonkauffman

Thank you for your support!


========[Copyright/Attribution Notice

SFX by Cleyton Kauffman - https://soundcloud.com/cleytonkauffman

========[License

Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)

You are free to:

Share � copy and redistribute the material in any medium or format

Adapt � remix, transform, and build upon the material

for any purpose, even commercially.